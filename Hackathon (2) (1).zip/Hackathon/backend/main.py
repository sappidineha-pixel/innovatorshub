from fastapi import FastAPI
from schemas import CodeRequest, CodeResponse
from debugger import debug_code

app = FastAPI(title="Bug Debug Chatbot")

@app.post("/debug", response_model=CodeResponse)
def debug(request: CodeRequest):

    bugs, explanation, improved = debug_code(
        request.code,
        request.language
    )

    return CodeResponse(
        bugs=bugs,
        explanation=explanation,
        improved_code=improved
    )