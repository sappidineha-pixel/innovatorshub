import streamlit as st
import requests

API_URL = "http://127.0.0.1:8000/debug"

st.title("🐞 AI Code Debugger")
st.write("Paste your code to detect bugs and get improved code.")

language = st.selectbox(
    "Programming Language",
    ["python", "javascript", "java", "c++"]
)

code_input = st.text_area(
    "Paste your code",
    height=300
)

if st.button("Debug Code"):

    if code_input.strip() == "":
        st.warning("Please paste some code.")
    else:

        payload = {
            "code": code_input,
            "language": language
        }

        with st.spinner("Analyzing code..."):

            response = requests.post(API_URL, json=payload)

        if response.status_code == 200:

            data = response.json()

            st.subheader("🐞 Bugs Found")
            st.write(data["bugs"])

            st.subheader("📖 Explanation")
            st.write(data["explanation"])

            st.subheader("✅ Improved Code")
            st.code(data["improved_code"], language=language)

        else:
            st.error("Backend error.")